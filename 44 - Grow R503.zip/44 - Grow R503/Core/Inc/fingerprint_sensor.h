#ifndef FINGERPRINT_SENSOR_H
#define FINGERPRINT_SENSOR_H

#include "stm32f1xx_hal.h"

#define FINGERPRINT_STARTCODE         0xEF01
#define FINGERPRINT_COMMANDPACKET     0x01
#define FINGERPRINT_ACKPACKET         0x07

// Commands
#define FINGERPRINT_VERIFYPASSWORD    0x13
#define FINGERPRINT_GETIMAGE          0x01
#define FINGERPRINT_IMAGE2TZ          0x02
#define FINGERPRINT_REGMODEL          0x05
#define FINGERPRINT_STORE             0x06
#define FINGERPRINT_LOAD              0x07
#define FINGERPRINT_MATCH             0x03
#define FINGERPRINT_LEDON             0x50
#define FINGERPRINT_LEDOFF            0x51
#define FINGERPRINT_READSYSPARAM      0x0F
#define FINGERPRINT_TEMPLATECOUNT     0x1D
#define FINGERPRINT_HISPEEDSEARCH     0x1B

// Responses
#define FINGERPRINT_OK                0x00
#define FINGERPRINT_PACKETRECIEVEERR  0x01
#define FINGERPRINT_NOFINGER          0x02
#define FINGERPRINT_IMAGEFAIL         0x03
#define FINGERPRINT_IMAGEMESS         0x06
#define FINGERPRINT_FEATUREFAIL       0x07
#define FINGERPRINT_NOMATCH           0x08
#define FINGERPRINT_NOTFOUND          0x09
#define FINGERPRINT_ENROLLMISMATCH    0x0A
#define FINGERPRINT_BADLOCATION       0x0B
#define FINGERPRINT_DBREADFAIL        0x0C
#define FINGERPRINT_UPLOADFEATUREFAIL 0x0D
#define FINGERPRINT_PACKETRESPONSEFAIL 0x0E
#define FINGERPRINT_UPLOADFAIL        0x0F
#define FINGERPRINT_DELETEFAIL        0x10
#define FINGERPRINT_DBCLEARFAIL       0x11
#define FINGERPRINT_PASSFAIL          0x13
#define FINGERPRINT_INVALIDIMAGE      0x15
#define FINGERPRINT_FLASHERR          0x18
#define FINGERPRINT_INVALIDREG        0x1A
#define FINGERPRINT_ADDRCODE          0x20
#define FINGERPRINT_PASSVERIFY        0x21

#define FINGERPRINT_TIMEOUT           0xFF
#define FINGERPRINT_BADPACKET         0xFE

typedef struct {
    UART_HandleTypeDef *huart;
    uint16_t finger_id;
    uint16_t confidence;
} Fingerprint_HandleTypeDef;

void Fingerprint_Init(Fingerprint_HandleTypeDef *fp, UART_HandleTypeDef *huart);
uint8_t Fingerprint_VerifyPassword(Fingerprint_HandleTypeDef *fp);
uint8_t Fingerprint_ReadSystemParams(Fingerprint_HandleTypeDef *fp);
uint8_t Fingerprint_GetImage(Fingerprint_HandleTypeDef *fp);
uint8_t Fingerprint_Image2Tz(Fingerprint_HandleTypeDef *fp, uint8_t slot);
uint8_t Fingerprint_CreateModel(Fingerprint_HandleTypeDef *fp);
uint8_t Fingerprint_StoreModel(Fingerprint_HandleTypeDef *fp, uint16_t location);
uint8_t Fingerprint_LoadModel(Fingerprint_HandleTypeDef *fp, uint16_t location);
uint8_t Fingerprint_MatchTemplate(Fingerprint_HandleTypeDef *fp);
uint8_t Fingerprint_LED(Fingerprint_HandleTypeDef *fp, uint8_t on);
uint8_t Fingerprint_GetTemplateCount(Fingerprint_HandleTypeDef *fp, uint16_t *count);
uint8_t Fingerprint_FastSearch(Fingerprint_HandleTypeDef *fp);

#endif // FINGERPRINT_SENSOR_H
