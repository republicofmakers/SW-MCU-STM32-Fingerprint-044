// fingerprint_sensor.c — FINAL FIXED VERSION
#include "fingerprint_sensor.h"
#include "main.h"
#include <string.h>
#include <stdio.h>

#define ADDRESS 0xFFFFFFFF

static void SendPacket(Fingerprint_HandleTypeDef *fp, uint8_t *data, uint16_t len) {
    uint8_t buffer[128];
    uint16_t sum = 0, total_len = len + 2;

    buffer[0] = (FINGERPRINT_STARTCODE >> 8) & 0xFF;
    buffer[1] = FINGERPRINT_STARTCODE & 0xFF;
    buffer[2] = (ADDRESS >> 24) & 0xFF;
    buffer[3] = (ADDRESS >> 16) & 0xFF;
    buffer[4] = (ADDRESS >> 8) & 0xFF;
    buffer[5] = ADDRESS & 0xFF;
    buffer[6] = FINGERPRINT_COMMANDPACKET;
    buffer[7] = (total_len >> 8) & 0xFF;
    buffer[8] = total_len & 0xFF;

    sum = FINGERPRINT_COMMANDPACKET + buffer[7] + buffer[8];

    for (uint16_t i = 0; i < len; i++) {
        buffer[9 + i] = data[i];
        sum += data[i];
    }

    buffer[9 + len] = (sum >> 8) & 0xFF;
    buffer[10 + len] = sum & 0xFF;

    HAL_UART_Transmit(fp->huart, buffer, 11 + len, HAL_MAX_DELAY);
}

static uint8_t ReceivePacket(Fingerprint_HandleTypeDef *fp, uint8_t *buffer, uint16_t max_len) {
    if (HAL_UART_Receive(fp->huart, buffer, 9, 2000) != HAL_OK)
        return FINGERPRINT_TIMEOUT;

    if (buffer[0] != 0xEF || buffer[1] != 0x01)
        return FINGERPRINT_BADPACKET;

    uint16_t packet_len = (buffer[7] << 8) | buffer[8];

    if (packet_len + 9 > max_len)
        return FINGERPRINT_BADPACKET;

    if (HAL_UART_Receive(fp->huart, &buffer[9], packet_len, 2000) != HAL_OK)
        return FINGERPRINT_TIMEOUT;

    return FINGERPRINT_OK;
}

void Fingerprint_Init(Fingerprint_HandleTypeDef *fp, UART_HandleTypeDef *huart) {
    fp->huart = huart;
    fp->finger_id = 0xFFFF;
    fp->confidence = 0;
}

uint8_t Fingerprint_VerifyPassword(Fingerprint_HandleTypeDef *fp) {
    uint8_t cmd[] = {FINGERPRINT_VERIFYPASSWORD, 0x00, 0x00, 0x00, 0x00};
    uint8_t resp[12];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return FINGERPRINT_TIMEOUT;
    return resp[9];
}

uint8_t Fingerprint_ReadSystemParams(Fingerprint_HandleTypeDef *fp) {
    uint8_t cmd[] = {FINGERPRINT_READSYSPARAM};
    uint8_t resp[28];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return FINGERPRINT_TIMEOUT;

    return FINGERPRINT_OK;
}

uint8_t Fingerprint_GetImage(Fingerprint_HandleTypeDef *fp) {
    uint8_t cmd[] = {FINGERPRINT_GETIMAGE};
    uint8_t resp[12];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    return resp[9];
}

uint8_t Fingerprint_Image2Tz(Fingerprint_HandleTypeDef *fp, uint8_t slot) {
    uint8_t cmd[] = {FINGERPRINT_IMAGE2TZ, slot};
    uint8_t resp[12];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    return resp[9];
}

uint8_t Fingerprint_CreateModel(Fingerprint_HandleTypeDef *fp) {
    uint8_t cmd[] = {FINGERPRINT_REGMODEL};
    uint8_t resp[12];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    return resp[9];
}

uint8_t Fingerprint_StoreModel(Fingerprint_HandleTypeDef *fp, uint16_t location) {
    uint8_t cmd[] = {FINGERPRINT_STORE, 0x01, location >> 8, location & 0xFF};
    uint8_t resp[12];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    return resp[9];
}

uint8_t Fingerprint_LoadModel(Fingerprint_HandleTypeDef *fp, uint16_t id) {
    uint8_t cmd[] = {FINGERPRINT_LOAD, 0x01, id >> 8, id & 0xFF};
    uint8_t resp[16];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    return resp[9];
}

uint8_t Fingerprint_MatchTemplate(Fingerprint_HandleTypeDef *fp) {
    uint8_t cmd[] = {FINGERPRINT_MATCH};
    uint8_t resp[16];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    fp->confidence = (resp[10] << 8) | resp[11];
    return resp[9];
}

uint8_t Fingerprint_LED(Fingerprint_HandleTypeDef *fp, uint8_t on) {
    uint8_t cmd[] = { on ? FINGERPRINT_LEDON : FINGERPRINT_LEDOFF };
    uint8_t resp[12];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    return resp[9];
}

uint8_t Fingerprint_GetTemplateCount(Fingerprint_HandleTypeDef *fp, uint16_t *count) {
    uint8_t cmd[] = {FINGERPRINT_TEMPLATECOUNT};
    uint8_t resp[14];
    SendPacket(fp, cmd, sizeof(cmd));
    if (ReceivePacket(fp, resp, sizeof(resp)) != FINGERPRINT_OK)
        return 0xFF;
    *count = (resp[10] << 8) | resp[11];
    return FINGERPRINT_OK;
}

uint8_t Fingerprint_FastSearch(Fingerprint_HandleTypeDef *fp) {
    uint8_t packet[] = {
        FINGERPRINT_HISPEEDSEARCH,
        0x01, 0x00, 0x00,
        0x00, 0xA3 // fixed 163 templates like the example
    };

    uint8_t response[32];
    SendPacket(fp, packet, sizeof(packet));
    if (ReceivePacket(fp, response, sizeof(response)) != FINGERPRINT_OK)
        return 0xFF;

    if (response[6] != FINGERPRINT_ACKPACKET || response[9] != FINGERPRINT_OK)
        return response[9];

    fp->finger_id = (response[10] << 8) | response[11];
    fp->confidence = (response[12] << 8) | response[13];

    return FINGERPRINT_OK;
}
